import pandas as pd

class Analyser:
    def __init__(self, log_file='system_log.csv'):
        self.log_file = log_file
        self.load_data()

    def load_data(self):
        self.data = pd.read_csv(self.log_file)

    def analyze(self, recommendations):
        interaction_threshold = 2  # Less than 2 interactions per session
        watch_time_threshold = 30  # Less than 30 minutes watched
        top_movie_pick_threshold = 1  # Less than 1 top movie picked

        total_watch_time = sum([rec['watch_percentage'] for rec in recommendations])
        top_movies_picked = sum([1 for rec in recommendations if rec['vote_average'] >= 8])

        if len(recommendations) < interaction_threshold or total_watch_time < watch_time_threshold or top_movies_picked < top_movie_pick_threshold:
            return True
        return False

    def get_adaptation_reason(self, recommendations):
        interaction_threshold = 2  # Less than 2 interactions per session
        watch_time_threshold = 30  # Less than 30 minutes watched
        top_movie_pick_threshold = 1  # Less than 1 top movie picked

        total_watch_time = sum([rec['watch_percentage'] for rec in recommendations])
        top_movies_picked = sum([1 for rec in recommendations if rec['vote_average'] >= 8])

        if len(recommendations) < interaction_threshold:
            return 'low_interaction'
        if total_watch_time < watch_time_threshold:
            return 'low_watch_time'
        if top_movies_picked < top_movie_pick_threshold:
            return 'low_top_movies_picked'
        return 'unknown'

# Example usage
if __name__ == "__main__":
    analyser = Analyser()
    print(analyser.analyze(analyser.load_data()))
