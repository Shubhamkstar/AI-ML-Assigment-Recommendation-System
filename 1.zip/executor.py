import pandas as pd

class Executor:
    def __init__(self, config_file='config.csv', params_file='params.csv'):
        self.config_file = config_file
        self.params_file = params_file

    def execute(self, action_plan):
        config = pd.read_csv(self.config_file)
        for param, value in action_plan.items():
            config.loc[config['parameter'] == param, 'value'] = value
        config.to_csv(self.config_file, index=False)

# Example usage
if __name__ == "__main__":
    executor = Executor()
    action_plan = {'num_recommendations': 15, 'imdb_rating_threshold': 7.0, 'similarity_metric': 'cosine'}
    executor.execute(action_plan)
    print("Config updated with action plan")
