class Planner:
    def __init__(self):
        pass

    def generate_action_plan(self, reason):
        action_plan = {}
        if reason == 'low_interaction':
            action_plan['num_recommendations'] = 5
        elif reason == 'low_watch_time':
            action_plan['imdb_rating_threshold'] = 5.0
        elif reason == 'low_top_movies_picked':
            action_plan['similarity_metric'] = 'linear'
        else:
            action_plan['num_recommendations'] = 10
        return action_plan

# Example usage
if __name__ == "__main__":
    planner = Planner()
    reason = 'low_interaction'
    print(planner.generate_action_plan(reason))
