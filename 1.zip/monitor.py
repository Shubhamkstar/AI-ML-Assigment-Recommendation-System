import csv
import time
from analyzer import analyze_data
from planner import plan_actions

log_file = 'system_log.csv'
last_processed_timestamp = None

def read_log_file():
    global last_processed_timestamp
    new_entries = []
    try:
        with open(log_file, 'r') as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                timestamp = row['timestamp']
                if last_processed_timestamp is None or timestamp > last_processed_timestamp:
                    new_entries.append(row)
                    last_processed_timestamp = timestamp
    except Exception as e:
        print(f"Error reading log file: {e}")
    return new_entries

def monitor():
    while True:
        new_entries = read_log_file()
        if new_entries:
            for entry in new_entries:
                print(f"New log entry: {entry}")
                analyze_data(entry)
                plan_actions(entry)
        time.sleep(5)

if __name__ == "__main__":
    monitor()
