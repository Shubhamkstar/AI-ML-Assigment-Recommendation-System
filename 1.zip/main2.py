import numpy as np
import pandas as pd
from flask import Flask, request, jsonify
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import pickle
import csv
from datetime import datetime

# Load the dataset
data = pd.read_csv('AJAX-Movie-Recommendation-System-with-Sentiment-Analysis/main_data.csv')

# Creating a count matrix and a similarity score matrix
cv = CountVectorizer()
count_matrix = cv.fit_transform(data['comb'])
similarity = cosine_similarity(count_matrix)

# Load the NLP model and TF-IDF vectorizer from disk
filename = 'AJAX-Movie-Recommendation-System-with-Sentiment-Analysis/nlp_model.pkl'
clf = pickle.load(open(filename, 'rb'))
vectorizer = pickle.load(open('AJAX-Movie-Recommendation-System-with-Sentiment-Analysis/tranform.pkl', 'rb'))

# Initialize CSV logging
log_file = 'AJAX-Movie-Recommendation-System-with-Sentiment-Analysis/flask_app_log.csv'
with open(log_file, 'w', newline='') as csvfile:
    fieldnames = ['timestamp', 'movie_title', 'recommended_movies']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()

def log_to_csv(movie_title, recommended_movies):
    with open(log_file, 'a', newline='') as csvfile:
        fieldnames = ['timestamp', 'movie_title', 'recommended_movies']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writerow({
            'timestamp': datetime.now(),
            'movie_title': movie_title,
            'recommended_movies': ', '.join([movie['title'] for movie in recommended_movies])
        })

def rcmd(m):
    m = m.lower()
    if m not in data['movie_title'].unique():
        return 'Sorry! The movie you requested is not in our database. Please check the spelling or try with some other movies'
    else:
        i = data.loc[data['movie_title'] == m].index[0]
        lst = list(enumerate(similarity[i]))
        lst = sorted(lst, key=lambda x: x[1], reverse=True)
        lst = lst[1:11]  # Excluding first item since it is the requested movie itself
        l = []
        for i in range(len(lst)):
            a = lst[i][0]
            l.append({
                'title': data['movie_title'][a],
                'genre': data['genres'][a],
                'position': i,
                'vote_average': data['vote_average'][a] if 'vote_average' in data.columns else None
            })
        return l

app = Flask(__name__)

@app.route("/recommend", methods=["POST"])
def recommend():
    movie = request.form['name']
    rc = rcmd(movie)
    if isinstance(rc, str):
        return jsonify({"error": rc})
    else:
        log_to_csv(movie, rc)
        return jsonify({"recommendations": rc})

if __name__ == '__main__':
    app.run(debug=True)
