import requests
import json
import pandas as pd
import time
import csv

def update_config(parameter, value):
    config = pd.read_csv('config.csv')
    config.loc[config['parameter'] == parameter, 'value'] = value
    config.to_csv('config.csv', index=False)

def update_params(parameter, value):
    params = pd.read_csv('params.csv')
    params.loc[params['parameter'] == parameter, 'value'] = str(value)
    params.to_csv('params.csv', index=False)

def test_recommendation_system():
    base_url = 'http://127.0.0.1:5000'
    log_file = 'test_log.csv'

    with open(log_file, 'w', newline='') as csvfile:
        fieldnames = ['test_case', 'parameter', 'value', 'status', 'result']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()

        # Test recommendations
        test_cases = [
            ('initial', 'num_recommendations', 5),
            ('initial', 'num_recommendations', 10),
            ('initial', 'imdb_rating_threshold', 5.0),
            ('initial', 'imdb_rating_threshold', 8.0),
            ('initial', 'similarity_metric', 'cosine'),
            ('initial', 'similarity_metric', 'linear'),
        ]

        for test_case, parameter, value in test_cases:
            update_config(parameter, value)

            time.sleep(1)  # Give time for the system to read the updated config

            # Test recommendation
            response = requests.post(f'{base_url}/recommend', data={'name': 'Inception'})
            if response.status_code == 200:
                result = response.json()
                status = 'OK'
            else:
                result = response.text
                status = 'FAIL'

            writer.writerow({'test_case': test_case, 'parameter': parameter, 'value': value, 'status': status,
                             'result': json.dumps(result)})

if __name__ == "__main__":
    test_recommendation_system()
